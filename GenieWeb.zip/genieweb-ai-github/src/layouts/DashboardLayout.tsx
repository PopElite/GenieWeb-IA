import { ReactNode } from 'react';
import Sidebar from '@/components/Sidebar';

type DashboardLayoutProps = {
  children: ReactNode;
};

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen bg-soft dark:bg-primary/95">
      <Sidebar>
        {children}
      </Sidebar>
    </div>
  );
}
