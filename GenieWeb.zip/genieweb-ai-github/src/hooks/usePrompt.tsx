import { useState } from 'react';

type UsePromptReturn = {
  prompt: string;
  setPrompt: (value: string) => void;
  isGenerating: boolean;
  startGeneration: () => Promise<string>;
  result: string | null;
  error: string | null;
  reset: () => void;
};

// Ce hook sera utilisé pour gérer les interactions avec les API d'IA
export function usePrompt(initialPrompt: string = ''): UsePromptReturn {
  const [prompt, setPrompt] = useState<string>(initialPrompt);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Cette fonction sera remplacée par l'appel API réel à OpenAI/Gemini/Claude
  const startGeneration = async (): Promise<string> => {
    if (!prompt.trim()) {
      setError('Veuillez entrer une requête');
      return '';
    }

    try {
      setIsGenerating(true);
      setError(null);
      
      // Simulation d'un appel API avec délai
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Résultat fictif pour le prototype
      const mockResult = `Résultat généré pour: "${prompt}".\n\nCeci est une simulation de réponse d'IA qui sera remplacée par l'intégration réelle avec l'API OpenAI/Gemini/Claude.`;
      
      setResult(mockResult);
      setIsGenerating(false);
      return mockResult;
    } catch (err) {
      setIsGenerating(false);
      const errorMessage = err instanceof Error ? err.message : 'Une erreur est survenue';
      setError(errorMessage);
      return '';
    }
  };

  const reset = () => {
    setPrompt('');
    setResult(null);
    setError(null);
  };

  return {
    prompt,
    setPrompt,
    isGenerating,
    startGeneration,
    result,
    error,
    reset
  };
}
