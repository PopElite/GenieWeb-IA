import { useState } from 'react';
import { generateAIContent } from '@/services/ai.service';

type UseAIPromptReturn = {
  prompt: string;
  setPrompt: (value: string) => void;
  isGenerating: boolean;
  startGeneration: () => Promise<string>;
  result: string | null;
  error: string | null;
  reset: () => void;
};

// Hook amélioré pour gérer les interactions avec l'API d'IA
export function useAIPrompt(initialPrompt: string = ''): UseAIPromptReturn {
  const [prompt, setPrompt] = useState<string>(initialPrompt);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Fonction pour lancer la génération de contenu
  const startGeneration = async (): Promise<string> => {
    if (!prompt.trim()) {
      setError('Veuillez entrer une requête');
      return '';
    }

    try {
      setIsGenerating(true);
      setError(null);
      
      // Appel au service AI pour générer le contenu
      const generatedContent = await generateAIContent(prompt);
      
      setResult(generatedContent);
      setIsGenerating(false);
      return generatedContent;
    } catch (err) {
      setIsGenerating(false);
      const errorMessage = err instanceof Error ? err.message : 'Une erreur est survenue';
      setError(errorMessage);
      return '';
    }
  };

  // Fonction pour réinitialiser l'état
  const reset = () => {
    setPrompt('');
    setResult(null);
    setError(null);
  };

  return {
    prompt,
    setPrompt,
    isGenerating,
    startGeneration,
    result,
    error,
    reset
  };
}
