import { ReactNode } from 'react';

type HistoryItemProps = {
  title: string;
  timestamp: Date;
  preview: string;
  onClick: () => void;
  className?: string;
};

export default function HistoryItem({
  title,
  timestamp,
  preview,
  onClick,
  className = ''
}: HistoryItemProps) {
  // Formatage de la date
  const formattedDate = new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(timestamp);

  return (
    <button
      onClick={onClick}
      className={`w-full text-left p-4 border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-primary/60 transition-colors ${className}`}
    >
      <div className="flex justify-between items-start">
        <h4 className="font-medium text-gray-900 dark:text-white">{title}</h4>
        <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">{formattedDate}</span>
      </div>
      <p className="mt-1 text-sm text-gray-600 dark:text-gray-300 line-clamp-2">{preview}</p>
    </button>
  );
}
