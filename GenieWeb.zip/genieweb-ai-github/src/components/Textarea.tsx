import { ReactNode } from 'react';

type TextareaProps = {
  id: string;
  label: string;
  placeholder?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  error?: string;
  required?: boolean;
  className?: string;
  rows?: number;
  maxLength?: number;
  helpText?: string;
  showCharCount?: boolean;
};

export default function Textarea({
  id,
  label,
  placeholder = '',
  value,
  onChange,
  error,
  required = false,
  className = '',
  rows = 4,
  maxLength,
  helpText,
  showCharCount = false
}: TextareaProps) {
  return (
    <div className={`mb-4 ${className}`}>
      <label 
        htmlFor={id} 
        className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
      >
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      
      <div className={`relative rounded-xl border ${
        error 
          ? 'border-red-500 dark:border-red-500' 
          : 'border-gray-300 dark:border-gray-600 focus-within:border-primary dark:focus-within:border-accent'
      } focus-within:ring-2 focus-within:ring-primary/30 dark:focus-within:ring-accent/30`}>
        <textarea
          id={id}
          className="block w-full rounded-xl bg-white dark:bg-primary/60 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none py-2.5 px-3"
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          required={required}
          rows={rows}
          maxLength={maxLength}
        />
      </div>
      
      <div className="flex justify-between mt-1">
        {(helpText && !error) && (
          <p className="text-sm text-gray-500 dark:text-gray-400">{helpText}</p>
        )}
        
        {error && (
          <p className="text-sm text-red-500">{error}</p>
        )}
        
        {(showCharCount && maxLength) && (
          <p className="text-sm text-gray-500 dark:text-gray-400 ml-auto">
            {value.length}/{maxLength}
          </p>
        )}
      </div>
    </div>
  );
}
