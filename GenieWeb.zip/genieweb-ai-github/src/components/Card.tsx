import { ReactNode } from 'react';

type CardProps = {
  title: string;
  children: ReactNode;
  icon?: string;
  className?: string;
  footer?: ReactNode;
};

export default function Card({ title, children, icon, className = '', footer }: CardProps) {
  return (
    <div className={`bg-white dark:bg-primary/80 rounded-2xl shadow-sm overflow-hidden ${className}`}>
      <div className="px-6 py-5 border-b border-gray-100 dark:border-gray-700 flex items-center">
        {icon && <span className="text-2xl mr-3">{icon}</span>}
        <h3 className="font-semibold text-lg text-gray-800 dark:text-white">{title}</h3>
      </div>
      <div className="p-6">
        {children}
      </div>
      {footer && (
        <div className="px-6 py-4 bg-gray-50 dark:bg-primary/60 border-t border-gray-100 dark:border-gray-700">
          {footer}
        </div>
      )}
    </div>
  );
}
