import { ReactNode } from 'react';

type AlertProps = {
  type: 'success' | 'error' | 'warning' | 'info';
  title?: string;
  children: ReactNode;
  className?: string;
  onClose?: () => void;
};

export default function Alert({
  type,
  title,
  children,
  className = '',
  onClose
}: AlertProps) {
  // Configuration des styles selon le type d'alerte
  const styles = {
    success: {
      bg: 'bg-green-50 dark:bg-green-900/20',
      border: 'border-green-400 dark:border-green-700',
      text: 'text-green-800 dark:text-green-400',
      icon: '✓',
    },
    error: {
      bg: 'bg-red-50 dark:bg-red-900/20',
      border: 'border-red-400 dark:border-red-700',
      text: 'text-red-800 dark:text-red-400',
      icon: '✕',
    },
    warning: {
      bg: 'bg-yellow-50 dark:bg-yellow-900/20',
      border: 'border-yellow-400 dark:border-yellow-700',
      text: 'text-yellow-800 dark:text-yellow-400',
      icon: '⚠',
    },
    info: {
      bg: 'bg-blue-50 dark:bg-blue-900/20',
      border: 'border-blue-400 dark:border-blue-700',
      text: 'text-blue-800 dark:text-blue-400',
      icon: 'ℹ',
    },
  };

  return (
    <div className={`rounded-xl border-l-4 p-4 ${styles[type].bg} ${styles[type].border} ${className}`}>
      <div className="flex items-start">
        <div className={`flex-shrink-0 mr-3 ${styles[type].text}`}>
          <span className="text-lg">{styles[type].icon}</span>
        </div>
        <div className="flex-1">
          {title && (
            <h3 className={`text-sm font-medium ${styles[type].text}`}>
              {title}
            </h3>
          )}
          <div className={`text-sm ${styles[type].text} mt-1`}>
            {children}
          </div>
        </div>
        {onClose && (
          <button
            type="button"
            className={`ml-auto -mx-1.5 -my-1.5 rounded-lg p-1.5 inline-flex ${styles[type].text} hover:bg-opacity-20 hover:bg-gray-500 focus:outline-none`}
            onClick={onClose}
            aria-label="Fermer"
          >
            <span className="sr-only">Fermer</span>
            <span className="text-lg">×</span>
          </button>
        )}
      </div>
    </div>
  );
}
