import { ReactNode } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

// Types pour les éléments de navigation
type NavItem = {
  label: string;
  href: string;
  icon: string; // Emoji comme icône pour le prototype
};

// Props pour le composant Sidebar
type SidebarProps = {
  children?: ReactNode;
};

export default function Sidebar({ children }: SidebarProps) {
  const pathname = usePathname();
  
  // Éléments de navigation
  const navItems: NavItem[] = [
    { label: 'Tableau de bord', href: '/dashboard', icon: '📊' },
    { label: 'Création de contenu', href: '/dashboard/content', icon: '✍️' },
    { label: 'Productivité', href: '/dashboard/productivity', icon: '⚡' },
    { label: 'Business', href: '/dashboard/business', icon: '💰' },
    { label: 'Formation', href: '/dashboard/learning', icon: '🎓' },
  ];
  
  // Modules IA
  const aiModules: NavItem[] = [
    { label: 'Générateur de posts', href: '/dashboard/post-generator', icon: '📱' },
    { label: 'Idées de microservices', href: '/dashboard/idea-generator', icon: '💡' },
    { label: 'Résumeur de contenu', href: '/dashboard/content-summarizer', icon: '📝' },
  ];

  return (
    <div className="flex h-screen bg-soft dark:bg-primary/95">
      {/* Sidebar - version desktop */}
      <div className="hidden md:flex flex-col w-64 bg-white dark:bg-primary/80 shadow-lg">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <Link href="/dashboard" className="flex items-center">
            <span className="text-2xl font-bold text-primary dark:text-white">GenieWeb AI</span>
          </Link>
        </div>
        
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="px-4 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center px-4 py-3 text-sm font-medium rounded-xl ${
                  pathname === item.href
                    ? 'bg-primary text-white dark:bg-accent'
                    : 'text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-primary/60'
                }`}
              >
                <span className="mr-3 text-xl">{item.icon}</span>
                {item.label}
              </Link>
            ))}
          </nav>
          
          <div className="mt-8 px-4">
            <h3 className="px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider dark:text-gray-400">
              Modules IA
            </h3>
            <nav className="mt-2 space-y-1">
              {aiModules.map((module) => (
                <Link
                  key={module.href}
                  href={module.href}
                  className={`flex items-center px-4 py-3 text-sm font-medium rounded-xl ${
                    pathname === module.href
                      ? 'bg-accent text-white'
                      : 'text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-primary/60'
                  }`}
                >
                  <span className="mr-3 text-xl">{module.icon}</span>
                  {module.label}
                </Link>
              ))}
            </nav>
          </div>
        </div>
        
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <Link
            href="/profile"
            className="flex items-center px-4 py-3 text-sm font-medium text-gray-700 rounded-xl hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-primary/60"
          >
            <span className="mr-3 text-xl">👤</span>
            Profil
          </Link>
          <button
            className="w-full mt-2 flex items-center px-4 py-3 text-sm font-medium text-gray-700 rounded-xl hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-primary/60"
          >
            <span className="mr-3 text-xl">🌙</span>
            Mode sombre
          </button>
        </div>
      </div>
      
      {/* Contenu principal */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header mobile */}
        <header className="md:hidden bg-white dark:bg-primary/80 shadow-sm py-4 px-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center">
            <span className="text-xl font-bold text-primary dark:text-white">GenieWeb AI</span>
          </Link>
          
          {/* Bouton menu mobile */}
          <button className="text-gray-600 dark:text-gray-200">
            <span className="text-2xl">☰</span>
          </button>
        </header>
        
        {/* Contenu de la page */}
        <main className="flex-1 overflow-y-auto bg-soft dark:bg-primary/95 p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
