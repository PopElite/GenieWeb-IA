import { ReactNode } from 'react';

type ResultCardProps = {
  title: string;
  content: string;
  actions?: ReactNode;
  className?: string;
  isLoading?: boolean;
};

export default function ResultCard({
  title,
  content,
  actions,
  className = '',
  isLoading = false
}: ResultCardProps) {
  return (
    <div className={`bg-white dark:bg-primary/80 rounded-2xl shadow-sm overflow-hidden ${className}`}>
      <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
        <h3 className="font-semibold text-lg text-gray-800 dark:text-white">{title}</h3>
        {actions}
      </div>
      
      <div className="p-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-pulse flex space-x-4 w-full">
              <div className="flex-1 space-y-4">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-4/6"></div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="prose dark:prose-invert max-w-none">
            <pre className="whitespace-pre-wrap text-sm md:text-base text-gray-800 dark:text-gray-200 font-sans">
              {content}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
