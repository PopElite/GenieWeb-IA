import { ReactNode } from 'react';

type ToggleProps = {
  id: string;
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  className?: string;
  disabled?: boolean;
  size?: 'sm' | 'md' | 'lg';
  description?: string;
};

export default function Toggle({
  id,
  label,
  checked,
  onChange,
  className = '',
  disabled = false,
  size = 'md',
  description
}: ToggleProps) {
  // Tailles du toggle
  const sizeStyles = {
    sm: {
      toggle: 'w-8 h-4',
      dot: 'h-3 w-3',
      translate: 'translate-x-4',
    },
    md: {
      toggle: 'w-11 h-6',
      dot: 'h-5 w-5',
      translate: 'translate-x-5',
    },
    lg: {
      toggle: 'w-14 h-7',
      dot: 'h-6 w-6',
      translate: 'translate-x-7',
    },
  };

  return (
    <div className={`flex items-center ${className}`}>
      <label className="inline-flex items-center cursor-pointer">
        <div className="relative">
          <input
            type="checkbox"
            id={id}
            className="sr-only"
            checked={checked}
            disabled={disabled}
            onChange={(e) => onChange(e.target.checked)}
          />
          <div
            className={`${sizeStyles[size].toggle} ${
              checked ? 'bg-accent' : 'bg-gray-200 dark:bg-gray-700'
            } rounded-full ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
          ></div>
          <div
            className={`absolute top-0.5 left-0.5 ${sizeStyles[size].dot} bg-white rounded-full transition-transform ${
              checked ? sizeStyles[size].translate : 'translate-x-0'
            }`}
          ></div>
        </div>
        <div className="ml-3">
          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
            {label}
          </span>
          {description && (
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {description}
            </p>
          )}
        </div>
      </label>
    </div>
  );
}
