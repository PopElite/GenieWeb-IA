import { useState } from 'react';
import Card from '@/components/Card';
import Input from '@/components/Input';
import Textarea from '@/components/Textarea';
import Button from '@/components/Button';
import ResultCard from '@/components/ResultCard';
import CopyButton from '@/components/CopyButton';
import Alert from '@/components/Alert';
import { useAIPrompt } from '@/hooks/useAIPrompt';

// Types pour les niches de marché
type MarketNiche = 'freelance' | 'ecommerce' | 'saas' | 'coaching' | 'content';

export default function IdeaGenerator() {
  // État pour les options de génération
  const [niche, setNiche] = useState<MarketNiche>('freelance');
  const [targetAudience, setTargetAudience] = useState('');
  const [skills, setSkills] = useState('');
  const [ideaCount, setIdeaCount] = useState(5);
  const [copySuccess, setCopySuccess] = useState(false);
  
  // Utilisation du hook useAIPrompt pour gérer l'interaction avec l'IA
  const { 
    prompt, 
    setPrompt, 
    isGenerating, 
    startGeneration, 
    result, 
    error, 
    reset 
  } = useAIPrompt();

  // Fonction pour générer le prompt basé sur les entrées utilisateur
  const generatePrompt = () => {
    const nicheText = {
      freelance: 'freelances et indépendants',
      ecommerce: 'e-commerce et vente en ligne',
      saas: 'logiciels SaaS et applications',
      coaching: 'coaching et formation',
      content: 'création de contenu et médias'
    };
    
    return `Génère ${ideaCount} idées de microservices rentables dans le domaine des ${nicheText[niche]}.

Audience cible: ${targetAudience || 'Professionnels et entrepreneurs'}
Compétences disponibles: ${skills || 'Compétences générales en business et technologie'}

Pour chaque idée, fournis:
1. Nom du microservice
2. Description courte (1-2 phrases)
3. Proposition de valeur unique
4. Modèle de tarification suggéré
5. Niveau de difficulté de mise en œuvre (Facile/Moyen/Difficile)`;
  };

  // Fonction pour soumettre la demande
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Générer le prompt complet
    const fullPrompt = generatePrompt();
    setPrompt(fullPrompt);
    
    // Lancer la génération
    await startGeneration();
  };

  // Fonction pour copier le résultat
  const handleCopy = () => {
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
        Générateur d'Idées de Microservices
      </h1>
      
      {copySuccess && (
        <Alert 
          type="success" 
          title="Copié avec succès!" 
          className="mb-4"
          onClose={() => setCopySuccess(false)}
        >
          Le contenu a été copié dans votre presse-papiers.
        </Alert>
      )}
      
      {error && (
        <Alert 
          type="error" 
          title="Erreur" 
          className="mb-4"
          onClose={() => reset()}
        >
          {error}
        </Alert>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Paramètres" icon="💡">
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Niche de marché
              </label>
              <div className="grid grid-cols-2 gap-2 mb-2">
                {[
                  { id: 'freelance', label: 'Freelance' },
                  { id: 'ecommerce', label: 'E-commerce' },
                  { id: 'saas', label: 'SaaS' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className={`py-2 px-3 rounded-xl text-sm font-medium ${
                      niche === item.id
                        ? 'bg-primary text-white dark:bg-accent'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-primary/60 dark:text-gray-200 dark:hover:bg-primary/80'
                    }`}
                    onClick={() => setNiche(item.id as MarketNiche)}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'coaching', label: 'Coaching' },
                  { id: 'content', label: 'Contenu' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className={`py-2 px-3 rounded-xl text-sm font-medium ${
                      niche === item.id
                        ? 'bg-primary text-white dark:bg-accent'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-primary/60 dark:text-gray-200 dark:hover:bg-primary/80'
                    }`}
                    onClick={() => setNiche(item.id as MarketNiche)}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
            
            <Input
              id="targetAudience"
              label="Audience cible (optionnel)"
              placeholder="Ex: Entrepreneurs débutants, Créateurs de contenu..."
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
            />
            
            <Textarea
              id="skills"
              label="Compétences disponibles (optionnel)"
              placeholder="Ex: Développement web, Marketing digital, Design graphique..."
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              rows={3}
            />
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Nombre d'idées à générer
              </label>
              <div className="flex items-center">
                <input
                  type="range"
                  min="3"
                  max="10"
                  value={ideaCount}
                  onChange={(e) => setIdeaCount(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                />
                <span className="ml-3 text-sm font-medium text-gray-700 dark:text-gray-300">
                  {ideaCount}
                </span>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end">
              <Button
                type="submit"
                disabled={isGenerating}
                isLoading={isGenerating}
              >
                {isGenerating ? 'Génération en cours...' : 'Générer des idées'}
              </Button>
            </div>
          </form>
        </Card>
        
        <ResultCard
          title="Idées générées"
          content={result || 'Les idées de microservices apparaîtront ici...'}
          isLoading={isGenerating}
          actions={
            result && (
              <CopyButton
                text={result}
                onCopy={handleCopy}
              />
            )
          }
        />
      </div>
    </div>
  );
}
