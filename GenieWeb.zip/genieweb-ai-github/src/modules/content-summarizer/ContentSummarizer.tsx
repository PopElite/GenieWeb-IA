import { useState } from 'react';
import Card from '@/components/Card';
import Input from '@/components/Input';
import Textarea from '@/components/Textarea';
import Button from '@/components/Button';
import ResultCard from '@/components/ResultCard';
import CopyButton from '@/components/CopyButton';
import Alert from '@/components/Alert';
import Tabs from '@/components/Tabs';
import { useAIPrompt } from '@/hooks/useAIPrompt';

// Types pour les sources de contenu
type ContentSource = 'text' | 'url';

// Types pour les types de résumé
type SummaryType = 'concise' | 'detailed' | 'bullets';

export default function ContentSummarizer() {
  // État pour les options de génération
  const [contentSource, setContentSource] = useState<ContentSource>('text');
  const [contentUrl, setContentUrl] = useState('');
  const [contentText, setContentText] = useState('');
  const [summaryType, setSummaryType] = useState<SummaryType>('concise');
  const [copySuccess, setCopySuccess] = useState(false);
  
  // Utilisation du hook useAIPrompt pour gérer l'interaction avec l'IA
  const { 
    prompt, 
    setPrompt, 
    isGenerating, 
    startGeneration, 
    result, 
    error, 
    reset 
  } = useAIPrompt();

  // Fonction pour générer le prompt basé sur les entrées utilisateur
  const generatePrompt = () => {
    const summaryTypeText = {
      concise: 'concis (environ 150 mots)',
      detailed: 'détaillé (environ 300 mots)',
      bullets: 'en points clés (5-10 points)'
    };
    
    let content = '';
    if (contentSource === 'text') {
      content = contentText;
    } else {
      content = `Contenu de l'URL: ${contentUrl}`;
    }
    
    return `Résume le contenu suivant de manière ${summaryTypeText[summaryType]}.

${content}

Format de la réponse:
${summaryType === 'bullets' ? '- Points clés numérotés' : 'Paragraphes cohérents avec introduction et conclusion'}
- Conserve les informations essentielles
- Utilise un langage clair et précis`;
  };

  // Fonction pour soumettre la demande
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if ((contentSource === 'text' && !contentText.trim()) || 
        (contentSource === 'url' && !contentUrl.trim())) {
      return;
    }
    
    // Générer le prompt complet
    const fullPrompt = generatePrompt();
    setPrompt(fullPrompt);
    
    // Lancer la génération
    await startGeneration();
  };

  // Fonction pour copier le résultat
  const handleCopy = () => {
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
        Résumeur de Contenu
      </h1>
      
      {copySuccess && (
        <Alert 
          type="success" 
          title="Copié avec succès!" 
          className="mb-4"
          onClose={() => setCopySuccess(false)}
        >
          Le résumé a été copié dans votre presse-papiers.
        </Alert>
      )}
      
      {error && (
        <Alert 
          type="error" 
          title="Erreur" 
          className="mb-4"
          onClose={() => reset()}
        >
          {error}
        </Alert>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Contenu à résumer" icon="📝">
          <form onSubmit={handleSubmit}>
            <Tabs
              tabs={[
                { id: 'text', label: 'Texte' },
                { id: 'url', label: 'URL' }
              ]}
              activeTab={contentSource}
              onChange={(tabId) => setContentSource(tabId as ContentSource)}
              className="mb-4"
            />
            
            {contentSource === 'text' ? (
              <Textarea
                id="contentText"
                label="Texte à résumer"
                placeholder="Collez ici le texte que vous souhaitez résumer..."
                value={contentText}
                onChange={(e) => setContentText(e.target.value)}
                rows={8}
                required
              />
            ) : (
              <Input
                id="contentUrl"
                label="URL de la page à résumer"
                placeholder="https://example.com/article"
                value={contentUrl}
                onChange={(e) => setContentUrl(e.target.value)}
                required
                helpText="Lien vers un article, une page web ou une vidéo YouTube"
              />
            )}
            
            <div className="mb-4 mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Type de résumé
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'concise', label: 'Concis' },
                  { id: 'detailed', label: 'Détaillé' },
                  { id: 'bullets', label: 'Points clés' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className={`py-2 px-3 rounded-xl text-sm font-medium ${
                      summaryType === item.id
                        ? 'bg-primary text-white dark:bg-accent'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-primary/60 dark:text-gray-200 dark:hover:bg-primary/80'
                    }`}
                    onClick={() => setSummaryType(item.id as SummaryType)}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="mt-6 flex justify-end">
              <Button
                type="submit"
                disabled={(contentSource === 'text' && !contentText.trim()) || 
                         (contentSource === 'url' && !contentUrl.trim()) ||
                         isGenerating}
                isLoading={isGenerating}
              >
                {isGenerating ? 'Résumé en cours...' : 'Générer le résumé'}
              </Button>
            </div>
          </form>
        </Card>
        
        <ResultCard
          title="Résumé généré"
          content={result || 'Le résumé apparaîtra ici...'}
          isLoading={isGenerating}
          actions={
            result && (
              <CopyButton
                text={result}
                onCopy={handleCopy}
              />
            )
          }
        />
      </div>
    </div>
  );
}
