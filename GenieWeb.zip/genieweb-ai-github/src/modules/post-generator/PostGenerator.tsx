import { useState } from 'react';
import Card from '@/components/Card';
import Input from '@/components/Input';
import Textarea from '@/components/Textarea';
import Button from '@/components/Button';
import ResultCard from '@/components/ResultCard';
import CopyButton from '@/components/CopyButton';
import Alert from '@/components/Alert';
import { useAIPrompt } from '@/hooks/useAIPrompt';

// Types pour les plateformes sociales
type Platform = 'linkedin' | 'twitter' | 'facebook' | 'instagram';

// Types pour les objectifs de post
type PostObjective = 'engagement' | 'conversion' | 'authority';

export default function PostGenerator() {
  // État pour les options de génération
  const [platform, setPlatform] = useState<Platform>('linkedin');
  const [objective, setObjective] = useState<PostObjective>('engagement');
  const [topic, setTopic] = useState('');
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [copySuccess, setCopySuccess] = useState(false);
  
  // Utilisation du hook useAIPrompt pour gérer l'interaction avec l'IA
  const { 
    prompt, 
    setPrompt, 
    isGenerating, 
    startGeneration, 
    result, 
    error, 
    reset 
  } = useAIPrompt();

  // Fonction pour générer le prompt basé sur les entrées utilisateur
  const generatePrompt = () => {
    const platformText = {
      linkedin: 'LinkedIn (professionnel, formel)',
      twitter: 'Twitter/X (concis, direct)',
      facebook: 'Facebook (conversationnel, informatif)',
      instagram: 'Instagram (visuel, engageant)'
    };
    
    const objectiveText = {
      engagement: 'maximiser l\'engagement (commentaires, partages)',
      conversion: 'générer des conversions (leads, ventes)',
      authority: 'établir une autorité dans le domaine'
    };
    
    return `Génère un post ${platformText[platform]} sur le sujet "${topic}" avec pour objectif de ${objectiveText[objective]}.
    
Informations supplémentaires: ${additionalInfo || 'Aucune'}

Format de la réponse:
- Accroche puissante
- Corps du message (2-3 paragraphes)
- Call-to-action
- Hashtags pertinents (5-7)`;
  };

  // Fonction pour soumettre la demande
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!topic.trim()) {
      return;
    }
    
    // Générer le prompt complet
    const fullPrompt = generatePrompt();
    setPrompt(fullPrompt);
    
    // Lancer la génération
    await startGeneration();
  };

  // Fonction pour copier le résultat
  const handleCopy = () => {
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
        Générateur de Posts pour Réseaux Sociaux
      </h1>
      
      {copySuccess && (
        <Alert 
          type="success" 
          title="Copié avec succès!" 
          className="mb-4"
          onClose={() => setCopySuccess(false)}
        >
          Le contenu a été copié dans votre presse-papiers.
        </Alert>
      )}
      
      {error && (
        <Alert 
          type="error" 
          title="Erreur" 
          className="mb-4"
          onClose={() => reset()}
        >
          {error}
        </Alert>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Paramètres" icon="✍️">
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Plateforme
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'linkedin', label: 'LinkedIn' },
                  { id: 'twitter', label: 'Twitter/X' },
                  { id: 'facebook', label: 'Facebook' },
                  { id: 'instagram', label: 'Instagram' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className={`py-2 px-3 rounded-xl text-sm font-medium ${
                      platform === item.id
                        ? 'bg-primary text-white dark:bg-accent'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-primary/60 dark:text-gray-200 dark:hover:bg-primary/80'
                    }`}
                    onClick={() => setPlatform(item.id as Platform)}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Objectif
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {[
                  { id: 'engagement', label: 'Engagement' },
                  { id: 'conversion', label: 'Conversion' },
                  { id: 'authority', label: 'Autorité' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className={`py-2 px-3 rounded-xl text-sm font-medium ${
                      objective === item.id
                        ? 'bg-primary text-white dark:bg-accent'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-primary/60 dark:text-gray-200 dark:hover:bg-primary/80'
                    }`}
                    onClick={() => setObjective(item.id as PostObjective)}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
            
            <Input
              id="topic"
              label="Sujet du post"
              placeholder="Ex: Stratégies d'automatisation pour freelances"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              required
            />
            
            <Textarea
              id="additionalInfo"
              label="Informations supplémentaires (optionnel)"
              placeholder="Détails spécifiques, ton souhaité, points à inclure..."
              value={additionalInfo}
              onChange={(e) => setAdditionalInfo(e.target.value)}
              rows={3}
            />
            
            <div className="mt-6 flex justify-end">
              <Button
                type="submit"
                disabled={!topic.trim() || isGenerating}
                isLoading={isGenerating}
              >
                {isGenerating ? 'Génération en cours...' : 'Générer le post'}
              </Button>
            </div>
          </form>
        </Card>
        
        <ResultCard
          title="Post généré"
          content={result || 'Le post généré apparaîtra ici...'}
          isLoading={isGenerating}
          actions={
            result && (
              <CopyButton
                text={result}
                onCopy={handleCopy}
              />
            )
          }
        />
      </div>
    </div>
  );
}
