import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/90 to-primary">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <header className="flex justify-between items-center mb-16">
          <div className="text-white font-bold text-2xl">GenieWeb AI</div>
          <div className="flex gap-4">
            <Link 
              href="/auth/login" 
              className="px-4 py-2 text-white hover:text-accent transition-colors"
            >
              Connexion
            </Link>
            <Link 
              href="/auth/signup" 
              className="px-6 py-2 bg-accent text-white rounded-xl hover:bg-accent/90 transition-colors"
            >
              Essayer gratuitement
            </Link>
          </div>
        </header>

        <main className="flex flex-col md:flex-row items-center gap-12 md:gap-24">
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Libère ton esprit, <span className="text-accent">multiplie ton impact.</span>
            </h1>
            <p className="text-lg md:text-xl text-soft mb-8">
              GenieWeb AI simplifie la vie digitale des entrepreneurs, freelancers et créateurs de contenu grâce à l'intelligence artificielle.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Link 
                href="/auth/signup" 
                className="px-8 py-3 bg-accent text-white rounded-xl text-lg font-medium hover:bg-accent/90 transition-colors"
              >
                Créer un compte
              </Link>
              <Link 
                href="#features" 
                className="px-8 py-3 bg-white/10 text-white rounded-xl text-lg font-medium hover:bg-white/20 transition-colors"
              >
                Découvrir les fonctionnalités
              </Link>
            </div>
          </div>
          <div className="flex-1 relative h-[300px] md:h-[500px] w-full">
            {/* Placeholder for hero image */}
            <div className="absolute inset-0 bg-accent/20 rounded-2xl flex items-center justify-center text-white">
              <span className="text-xl">Interface AI Dashboard</span>
            </div>
          </div>
        </main>

        <section id="features" className="py-24">
          <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-16">
            Propulsez votre activité avec l'IA
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Création de contenu',
                description: 'Générez des posts impactants, des scripts vidéo et des visuels qui captivent votre audience.',
                icon: '✍️'
              },
              {
                title: 'Productivité automatisée',
                description: 'Résumez des documents, rédigez des emails professionnels et planifiez votre semaine efficacement.',
                icon: '⚡'
              },
              {
                title: 'Génération de revenus',
                description: 'Découvrez des idées de microservices, créez des tunnels de vente et optimisez vos landing pages.',
                icon: '💰'
              }
            ].map((feature, index) => (
              <div key={index} className="bg-white/10 p-8 rounded-2xl hover:bg-white/15 transition-colors">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                <p className="text-soft">{feature.description}</p>
              </div>
            ))}
          </div>
        </section>

        <footer className="border-t border-white/10 py-8 text-center text-white/60">
          <p>© 2025 GenieWeb AI. Tous droits réservés.</p>
        </footer>
      </div>
    </div>
  );
}
