import { useState, useEffect } from 'react';
import DashboardLayout from '@/layouts/DashboardLayout';
import Card from '@/components/Card';
import Button from '@/components/Button';
import Alert from '@/components/Alert';
import PostGenerator from '@/modules/post-generator/PostGenerator';
import IdeaGenerator from '@/modules/idea-generator/IdeaGenerator';
import ContentSummarizer from '@/modules/content-summarizer/ContentSummarizer';

// Composant pour tester le responsive design
export default function ResponsiveTest() {
  const [currentBreakpoint, setCurrentBreakpoint] = useState('');
  const [isMounted, setIsMounted] = useState(false);
  const [showAlert, setShowAlert] = useState(false);

  // Détecter la taille de l'écran actuelle
  useEffect(() => {
    setIsMounted(true);
    
    const updateBreakpoint = () => {
      const width = window.innerWidth;
      if (width < 640) {
        setCurrentBreakpoint('xs (< 640px)');
      } else if (width < 768) {
        setCurrentBreakpoint('sm (640px - 767px)');
      } else if (width < 1024) {
        setCurrentBreakpoint('md (768px - 1023px)');
      } else if (width < 1280) {
        setCurrentBreakpoint('lg (1024px - 1279px)');
      } else {
        setCurrentBreakpoint('xl (≥ 1280px)');
      }
    };
    
    updateBreakpoint();
    window.addEventListener('resize', updateBreakpoint);
    
    return () => {
      window.removeEventListener('resize', updateBreakpoint);
    };
  }, []);

  // Afficher l'alerte de test
  const handleShowAlert = () => {
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 3000);
  };

  if (!isMounted) {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Test Responsive Design
        </h1>
        <p className="mt-1 text-gray-600 dark:text-gray-300">
          Cette page permet de tester le responsive design de l'application.
        </p>
      </div>
      
      {showAlert && (
        <Alert 
          type="success" 
          title="Test réussi!" 
          className="mb-4"
          onClose={() => setShowAlert(false)}
        >
          Cette alerte est affichée pour tester les composants UI.
        </Alert>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card title="Informations sur l'écran" icon="📱">
          <div className="space-y-4">
            <div>
              <p className="font-medium">Breakpoint actuel:</p>
              <p className="text-lg text-accent">{currentBreakpoint}</p>
            </div>
            
            <div>
              <p className="font-medium">Dimensions de la fenêtre:</p>
              <p>{window.innerWidth} x {window.innerHeight} pixels</p>
            </div>
            
            <div className="pt-2">
              <Button onClick={handleShowAlert}>
                Tester les alertes
              </Button>
            </div>
          </div>
        </Card>
        
        <Card title="Grille responsive" icon="🔲">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div 
                key={i} 
                className="bg-primary/10 dark:bg-primary/30 p-4 rounded-lg flex items-center justify-center"
              >
                Item {i + 1}
              </div>
            ))}
          </div>
        </Card>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
          Éléments UI à tester
        </h2>
        
        <div className="flex flex-wrap gap-2">
          <Button variant="primary">Bouton primaire</Button>
          <Button variant="secondary">Bouton secondaire</Button>
          <Button variant="outline">Bouton outline</Button>
          <Button variant="ghost">Bouton ghost</Button>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Button size="sm">Petit</Button>
          <Button size="md">Moyen</Button>
          <Button size="lg">Grand</Button>
        </div>
        
        <div className="mt-8">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
            Modules IA
          </h2>
          
          <div className="space-y-8">
            <div className="border-b border-gray-200 dark:border-gray-700 pb-8">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Générateur de Posts
              </h3>
              <PostGenerator />
            </div>
            
            <div className="border-b border-gray-200 dark:border-gray-700 pb-8">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Générateur d'Idées
              </h3>
              <IdeaGenerator />
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Résumeur de Contenu
              </h3>
              <ContentSummarizer />
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
