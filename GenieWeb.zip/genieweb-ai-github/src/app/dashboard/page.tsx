import DashboardLayout from '@/layouts/DashboardLayout';
import Card from '@/components/Card';
import ThemeToggle from '@/components/ThemeToggle';
import { useAuth } from '@/hooks/useAuth';

export default function Dashboard() {
  const { user } = useAuth();
  
  // Modules disponibles
  const modules = [
    {
      id: 'post-generator',
      title: 'Générateur de posts LinkedIn',
      description: 'Créez des posts professionnels et engageants pour LinkedIn en quelques clics.',
      icon: '✍️',
      href: '/dashboard/post-generator'
    },
    {
      id: 'idea-generator',
      title: 'Générateur d\'idées de microservices',
      description: 'Découvrez des idées de services rentables adaptés à votre niche et vos compétences.',
      icon: '💡',
      href: '/dashboard/idea-generator'
    },
    {
      id: 'content-summarizer',
      title: 'Résumeur de contenu',
      description: 'Résumez rapidement des articles, documents ou vidéos pour gagner du temps.',
      icon: '📝',
      href: '/dashboard/content-summarizer'
    }
  ];

  return (
    <DashboardLayout>
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Tableau de bord
          </h1>
          <p className="mt-1 text-gray-600 dark:text-gray-300">
            Bienvenue {user?.name || 'sur GenieWeb AI'}, que souhaitez-vous faire aujourd'hui?
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <ThemeToggle variant="button" />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {modules.map((module) => (
          <a 
            key={module.id}
            href={module.href}
            className="block transition-transform hover:scale-[1.02]"
          >
            <Card 
              title={module.title} 
              icon={module.icon}
              className="h-full"
            >
              <p className="text-gray-600 dark:text-gray-300">
                {module.description}
              </p>
              <div className="mt-4 text-accent font-medium">
                Utiliser cet outil →
              </div>
            </Card>
          </a>
        ))}
      </div>
      
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Activité récente" icon="🕒">
          <p className="text-gray-600 dark:text-gray-300 py-8 text-center">
            Votre historique d'activité apparaîtra ici.
          </p>
        </Card>
        
        <Card title="Conseils d'utilisation" icon="💬">
          <ul className="space-y-3 text-gray-600 dark:text-gray-300">
            <li className="flex">
              <span className="mr-2">•</span>
              <span>Utilisez des prompts détaillés pour obtenir de meilleurs résultats</span>
            </li>
            <li className="flex">
              <span className="mr-2">•</span>
              <span>Vous pouvez modifier et régénérer le contenu autant de fois que nécessaire</span>
            </li>
            <li className="flex">
              <span className="mr-2">•</span>
              <span>Activez le mode sombre pour réduire la fatigue oculaire</span>
            </li>
            <li className="flex">
              <span className="mr-2">•</span>
              <span>N'hésitez pas à nous faire part de vos suggestions d'amélioration</span>
            </li>
          </ul>
        </Card>
      </div>
    </DashboardLayout>
  );
}
