import { Configuration, OpenAIApi } from 'openai';

// Classe pour gérer les interactions avec l'API OpenAI
class OpenAIService {
  private api: OpenAIApi | null = null;
  
  constructor() {
    this.initialize();
  }
  
  private initialize() {
    try {
      // En production, la clé API serait stockée dans les variables d'environnement
      // process.env.OPENAI_API_KEY
      const configuration = new Configuration({
        apiKey: process.env.NEXT_PUBLIC_OPENAI_API_KEY || 'sk-dummy-key-for-development',
      });
      
      this.api = new OpenAIApi(configuration);
      console.log('Service OpenAI initialisé');
    } catch (error) {
      console.error('Erreur lors de l\'initialisation du service OpenAI:', error);
    }
  }
  
  // Méthode pour générer du texte avec l'API OpenAI
  async generateContent(prompt: string): Promise<string> {
    if (!this.api) {
      throw new Error('Le service OpenAI n\'est pas initialisé');
    }
    
    try {
      console.log('Envoi de la requête à OpenAI:', prompt.substring(0, 100) + '...');
      
      // En mode développement, simuler une réponse
      if (!process.env.NEXT_PUBLIC_OPENAI_API_KEY || process.env.NODE_ENV === 'development') {
        console.log('Mode développement: simulation de réponse');
        await new Promise(resolve => setTimeout(resolve, 1500));
        return this.generateMockResponse(prompt);
      }
      
      // En production, appeler l'API réelle
      const response = await this.api.createChatCompletion({
        model: "gpt-4",
        messages: [
          { role: "system", content: "Tu es un assistant IA expert en marketing, business et création de contenu." },
          { role: "user", content: prompt }
        ],
        max_tokens: 1000,
        temperature: 0.7,
      });
      
      return response.data.choices[0]?.message?.content || 'Aucune réponse générée.';
    } catch (error) {
      console.error('Erreur lors de la génération de contenu:', error);
      throw error;
    }
  }
  
  // Méthode pour générer une réponse simulée en mode développement
  private generateMockResponse(prompt: string): string {
    // Détecter le type de contenu demandé
    if (prompt.includes('post') && prompt.includes('LinkedIn')) {
      return `# Post LinkedIn généré

**Accroche puissante:**
🚀 L'automatisation n'est plus un luxe, c'est une nécessité pour les freelances qui veulent rester compétitifs en 2025!

**Corps du message:**
Après avoir analysé les données de plus de 500 freelances, j'ai constaté que ceux qui automatisent au moins 30% de leurs tâches administratives augmentent leur revenu de 40% en moyenne.

Pourquoi? Simple: chaque heure économisée sur des tâches répétitives devient une heure que vous pouvez facturer ou investir dans votre développement. L'effet cumulé sur une année est stupéfiant.

J'ai compilé les 5 workflows d'automatisation les plus rentables pour les freelances dans tous les domaines. Le #3 m'a permis personnellement d'économiser 12h par mois!

**Call-to-action:**
👇 Commentez "INFO" ci-dessous et je vous enverrai gratuitement mon guide d'automatisation pour freelances.

**Hashtags:**
#ProductivitéFreelance #Automatisation #BusinessGrowth #DigitalTools #WorkSmarter #FreelanceLifestyle #EntrepreneuriatDigital`;
    } else if (prompt.includes('idées') && prompt.includes('microservices')) {
      return `# Idées de microservices dans le domaine du freelance

## 1. FreelanceCheckup
**Description:** Service d'audit express de présence en ligne pour freelances
**Proposition de valeur:** Analyse complète du positionnement digital en 24h avec recommandations actionnables
**Modèle de tarification:** 97€ par audit ou 197€ avec suivi personnalisé de 30 jours
**Difficulté:** Facile

## 2. ClientMatchPro
**Description:** Système de mise en relation qualifiée entre freelances et clients potentiels
**Proposition de valeur:** Algorithme de matching basé sur 15 critères de compatibilité pour des collaborations réussies
**Modèle de tarification:** Abonnement mensuel de 49€ + commission de 3% sur les contrats signés
**Difficulté:** Moyen

## 3. InvoiceGenius
**Description:** Automatisation intelligente de la facturation et des relances pour freelances
**Proposition de valeur:** Réduction de 80% du temps consacré à la facturation et amélioration du taux de paiement à temps
**Modèle de tarification:** Freemium avec limite de 5 clients, puis 15€/mois jusqu'à 20 clients
**Difficulté:** Moyen

## 4. ProposalCraft
**Description:** Générateur de propositions commerciales personnalisées avec IA
**Proposition de valeur:** Création de devis professionnels en 10 minutes au lieu de plusieurs heures
**Modèle de tarification:** 29€/mois ou 7€ par proposition générée
**Difficulté:** Facile

## 5. FreelanceInsights
**Description:** Tableau de bord analytique pour suivre et optimiser son activité freelance
**Proposition de valeur:** Visualisation claire de la rentabilité par client, projet et heure travaillée
**Modèle de tarification:** 19€/mois ou 190€/an avec accès aux benchmarks sectoriels
**Difficulté:** Moyen`;
    } else if (prompt.includes('résume')) {
      return `# Résumé du contenu

Le texte présente les avantages de l'intelligence artificielle pour les créateurs de contenu et entrepreneurs. Il met en avant trois bénéfices principaux:

1. **Gain de temps significatif** grâce à l'automatisation des tâches répétitives comme la recherche, la correction et la mise en forme, permettant aux créateurs de se concentrer sur les aspects créatifs et stratégiques.

2. **Amélioration de la qualité** des contenus produits, avec des suggestions pertinentes, une aide à la structuration et une optimisation pour différentes plateformes.

3. **Augmentation de la productivité** globale, avec la possibilité de produire davantage de contenu sans sacrifier la qualité, et d'expérimenter plus facilement différentes approches.

Le texte conclut que l'IA ne remplace pas la créativité humaine mais agit comme un amplificateur de compétences, permettant aux créateurs de se démarquer dans un environnement digital de plus en plus concurrentiel.`;
    } else {
      return `Contenu généré en réponse à votre demande.

Ceci est une simulation de réponse pour le développement. Dans l'environnement de production, ce contenu sera généré par l'API OpenAI en fonction de votre prompt spécifique.

Le contenu généré sera formaté selon les instructions fournies dans votre prompt et adapté au contexte de votre demande.`;
    }
  }
}

// Export d'une instance singleton
export const openAIService = new OpenAIService();

// Fonction utilitaire pour appeler l'API
export async function generateAIContent(prompt: string): Promise<string> {
  try {
    return await openAIService.generateContent(prompt);
  } catch (error) {
    console.error('Erreur lors de la génération de contenu:', error);
    throw new Error('Impossible de générer le contenu. Veuillez réessayer plus tard.');
  }
}
